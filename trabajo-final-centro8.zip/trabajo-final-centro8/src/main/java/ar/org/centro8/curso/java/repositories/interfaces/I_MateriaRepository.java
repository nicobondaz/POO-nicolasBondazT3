package ar.org.centro8.curso.java.repositories.interfaces;

import java.sql.SQLException;
import java.util.List;

import ar.org.centro8.curso.java.entities.Materia;

public interface I_MateriaRepository {
    void create(Materia materia) throws SQLException;
    Materia findById(int id) throws SQLException;
    List<Materia> findAll() throws SQLException;
    int update(Materia materia) throws SQLException;
    int delete(int id) throws SQLException;
    List<Materia> findByProfesor(int idProfesor) throws SQLException;
}
