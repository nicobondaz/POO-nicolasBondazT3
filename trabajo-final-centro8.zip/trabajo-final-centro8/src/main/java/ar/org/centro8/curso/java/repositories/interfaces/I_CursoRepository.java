package ar.org.centro8.curso.java.repositories.interfaces;

import java.sql.SQLException;
import java.util.List;

import ar.org.centro8.curso.java.entities.Curso;
import ar.org.centro8.curso.java.enums.Turno;

public interface I_CursoRepository {
    void create(Curso curso) throws SQLException;
    Curso findById(int id) throws SQLException;
    List<Curso> findAll() throws SQLException;
    int update(Curso curso) throws SQLException;
    int delete(int id) throws SQLException;
    List<Curso> findByAnioAndTurno(int anio, Turno turno);
}
