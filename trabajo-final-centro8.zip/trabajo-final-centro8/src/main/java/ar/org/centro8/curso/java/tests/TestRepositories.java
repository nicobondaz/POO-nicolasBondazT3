package ar.org.centro8.curso.java.tests;

import java.time.LocalDate;
import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import ar.org.centro8.curso.java.entities.Alumno;
import ar.org.centro8.curso.java.entities.Calificacion;
import ar.org.centro8.curso.java.entities.Curso;
import ar.org.centro8.curso.java.entities.Materia;
import ar.org.centro8.curso.java.entities.Profesor;
import ar.org.centro8.curso.java.enums.Division;
import ar.org.centro8.curso.java.enums.Nivel;
import ar.org.centro8.curso.java.enums.TipoEvaluacion;
import ar.org.centro8.curso.java.enums.Turno;
import ar.org.centro8.curso.java.repositories.interfaces.I_AlumnoRepository;
import ar.org.centro8.curso.java.repositories.interfaces.I_CalificacionRepository;
import ar.org.centro8.curso.java.repositories.interfaces.I_CursoRepository;
import ar.org.centro8.curso.java.repositories.interfaces.I_MateriaRepository;
import ar.org.centro8.curso.java.repositories.interfaces.I_ProfesorRepository;

@SpringBootApplication(scanBasePackages = "ar.org.centro8.curso.java")

public class TestRepositories {
    public static void main(String[] args) {
        try (ConfigurableApplicationContext context = SpringApplication.run(TestRepositories.class, args)) {
            I_AlumnoRepository alumnoRepository = context.getBean(I_AlumnoRepository.class);
            I_CursoRepository cursoRepository = context.getBean(I_CursoRepository.class);
            I_ProfesorRepository profesorRepository = context.getBean(I_ProfesorRepository.class);
            I_MateriaRepository materiaRepository = context.getBean(I_MateriaRepository.class);
            I_CalificacionRepository calificacionRepository = context.getBean(I_CalificacionRepository.class);

            // Crear Alumno
            System.out.println("\n>>> Test 1: creando un nuevo alumno...");
            Alumno nuevoAlumno = new Alumno(0, "Juan", "Pérez", "12345678", LocalDate.of(2000, 1, 1),
                    "nicocrack123@gmail.com", "Sandra Perez y Juan Cito", 1);
            alumnoRepository.create(nuevoAlumno);
            if (nuevoAlumno.getIdAlumno() > 0) {
                System.out.println("## Alumno creado con el ID: " + nuevoAlumno.getIdAlumno());
                System.out.println(nuevoAlumno);
            } else {
                System.err.println(" ¡¡ ERROR - no se pudo crear el alumno !!");
            }

            // buscando alumno por ID existente
            System.out.println("\n>>> Test 2: buscando el alumno por ID " + nuevoAlumno.getIdAlumno() + "...");
            Alumno alumnoEncontrado = alumnoRepository.findById(nuevoAlumno.getIdAlumno());
            if (alumnoEncontrado != null) {
                System.out.println("## Alumno encontrado: " + alumnoEncontrado);
            } else {
                System.err.println(" ¡¡ ERROR - no se encontró el alumno con el ID " + nuevoAlumno.getIdAlumno());
            }
            // buscando alumno por ID inexistente
            System.out.println("\n>>> Test 3 : buscando un alumno con un ID inexistente");
            Alumno alumnoNoEncontrado = alumnoRepository.findById(9999);
            if (alumnoNoEncontrado != null) {
                System.out.println("## Alumno encontrado: " + alumnoNoEncontrado);
            } else {
                System.err.println(" ¡¡ ERROR - se encontró un alumno con ID 999 !!");
            }

            //Listar todos los alumnos
            System.out.println("\n>>> Test 5: Listando todos los alumnos...");
            List<Alumno> alumnosTodos = alumnoRepository.findAll();
            if(!alumnosTodos.isEmpty()){
                System.out.println(" ## Alumnos encontrados: " + alumnosTodos.size());
                alumnosTodos.forEach(System.out::println);
            } else {
                System.err.println(" ¡¡ ERROR - no se encontraron alumnos");
            }

            //Buscar alumno por curso
            System.out.println("\n>>> Test : buscando Alumno por curso");
            List<Alumno> alumnosCurso = alumnoRepository.findByCurso(3);
            if(!alumnosCurso.isEmpty()){
                System.out.println(" ## Alumnos encontrados : " + alumnosCurso.size());
                alumnosCurso.forEach(System.out::println);
            } else{
                System.err.println(" ¡¡ No se encontraron Alumnos en el curso");
            }


            // Actualizando un alumno
            System.out.println("\n>>> 4: Actualizando Alumno " + nuevoAlumno.getIdAlumno() + "...");
            nuevoAlumno.setNombre("Ricardo Horacio");
            int filasAfectadas = alumnoRepository.update(nuevoAlumno);
            if (filasAfectadas == 1) {
                System.out.println("## Alumno " + nuevoAlumno.getIdAlumno() + "actualizado correctamente");
                System.out.println(
                        "## Verificando actualización: " + alumnoRepository.findById(nuevoAlumno.getIdAlumno()));
            } else {
                System.err.println(" ¡¡ ERROR - No se pudo actualizar al alumno !!");
            }

            // Eliminar un alumno
            System.out.println("\n>>> Test 6: Eliminando Alumno " + nuevoAlumno.getIdAlumno() + "...");
            int filasAfectadasDelete = alumnoRepository.delete(nuevoAlumno.getIdAlumno());
            if (filasAfectadasDelete == 1) {
                System.out.println("## Alumno " + nuevoAlumno.getIdAlumno() + "eliminado correctamente");
                System.out.println("Verificando eliminacion: " + alumnoRepository.findById(nuevoAlumno.getIdAlumno()));
            } else {
                System.err.println("¡¡ ERROR - No se pudo eliminar al alumno !!");
            }

            // Pruebas para Curso

            // Creando un curso
            System.out.println("\n>>> Test 7: creando un nuevo Curso...");
            Curso nuevoCurso = new Curso(0, 1, Nivel.SECUNDARIA, Turno.TARDE, Division.ECONOMIA);
            cursoRepository.create(nuevoCurso);
            if (nuevoCurso.getIdCurso() > 0) {
                System.out.println("## Curso creado correctamente con id " + nuevoCurso.getIdCurso() + "...");
            } else {
                System.err.println("¡¡ ERROR - no se pudo crear el curso");
            }

            // Buscando curso por id
            System.out.println("\n Test 8: buscando curso por Id " + nuevoCurso.getIdCurso() + "...");
            Curso cursoEncontrado = cursoRepository.findById(nuevoCurso.getIdCurso());
            if (cursoEncontrado != null) {
                System.out.println("## Cursos encontrados: " + cursoEncontrado);
            } else {
                System.err.println("¡¡ ERROR - No se encontraron cursos !!");
            }

            // Buscar todos los cursos
            System.out.println("\n>>> Test 9: listar todos los cursos");
            List<Curso> cursosTodos = cursoRepository.findAll();
            if (!cursosTodos.isEmpty()) {
                System.out.println("## Cursos encontrados: " + cursosTodos.size());
                cursosTodos.forEach(System.out::println);
            } else {
                System.err.println("¡¡ ERROR - No se encontraron cursos !!");
            }

            //Listando Cursos por año y turno
            System.out.println("\n>>> Test 10: buscando cursos por anio y turno");
            List<Curso> cursosSegundoManiana = cursoRepository.findByAnioAndTurno(2, Turno.MAÑANA);
            if (!cursosSegundoManiana.isEmpty()) {
                System.out.println("## Cursos encontrados (Segundo, Mañana) " + cursosSegundoManiana.size());
                cursosSegundoManiana.forEach(System.out::println);
            } else {
                System.err.println("¡¡ No se encontraron cursos para Segundo por Mañana");
            }

            // Actualizar un curso
            System.out.println("\n>>> Test 11: Actualizando Curso " + nuevoCurso.getIdCurso() + "...");
            nuevoCurso.setAnio(5);
            nuevoCurso.setNivel(Nivel.SECUNDARIA);
            nuevoCurso.setTurno(Turno.TARDE);
            nuevoCurso.setDivision(Division.ECONOMIA);
            int filasAfectadasCurso = cursoRepository.update(nuevoCurso);
            if (filasAfectadasCurso == 1) {
                System.out.println("## Curso " + nuevoCurso.getIdCurso() + "actualizado correctamente");
                System.out.println("Verificando actualizacion " + cursoRepository.findById(nuevoCurso.getIdCurso()));
            } else {
                System.err.println("¡¡ ERROR - no se pudo actualizar el curso");
            }

            // Eliminando un curso
            System.out.println("\n Test 12: Eliminando curso por ID " + nuevoCurso.getIdCurso());
            int filasAfectadasCursoDelete = cursoRepository.delete(nuevoCurso.getIdCurso());
            if (filasAfectadasCursoDelete == 1) {
                System.out.println("## Curso " + nuevoCurso.getIdCurso() + " eliminado correctamente");
                System.out.println("Verificando eliminacion " + cursoRepository.findById(nuevoCurso.getIdCurso()));
            } else {
                System.err.println("¡¡ ERROR - no se pudo eliminar el curso !!");
            }

            // Pruebas para Profesor


            //Creando un profesor
            System.out.println("\n Test 13: Creando un Profesor");
            Profesor nuevoProfesor = new Profesor(0, "Nicolas", "Bondaz", "55667897",LocalDate.of(2005, 7, 4), "nicocrack33@gmail.com", "1134561789" , "Matematica");
            profesorRepository.create(nuevoProfesor);
            if (nuevoProfesor.getIdProfesor()>0) {
                System.out.println("## Profesor creado con el ID " + nuevoProfesor.getIdProfesor());
                System.out.println(nuevoProfesor);
            }else{
                System.err.println("¡¡ ERROR - no se pudo crear el profesor");
            }

            //Buscando un profesor por su ID
            System.out.println("\n Test 14: Buscando un profesor por su ID");
            Profesor profesorEncontrado = profesorRepository.findById(nuevoProfesor.getIdProfesor());
            if (profesorEncontrado!=null) {
                System.out.println("## Profesor encontrado: " + profesorEncontrado);
            }else{
                System.err.println("¡¡ ERROR - no se pudo encontrar al profesor");
            }

            //Buscando un profesor por ID Inexistente 
            System.out.println("\n Test 15: Buscando un profesor por su ID 9999 inexistente");
            Profesor profesorNoEncontrado = profesorRepository.findById(999);
            if (profesorNoEncontrado!= null) {
                System.out.println("## Profesor encontrado: " + profesorEncontrado);
            }else{
                System.err.println("¡¡ ERROR - no se pudo encontrar al profesor");
            }

            //actualizar un profesor
            System.out.println("\n Test 16: Actualizando un profesor " + nuevoProfesor.getIdProfesor());
            nuevoProfesor.setNombre("Martin");
            int filasAfectadasProfesor = profesorRepository.update(nuevoProfesor);
            if (filasAfectadasProfesor==1) {
                System.out.println("## profesor " + nuevoProfesor.getIdProfesor() + "actualizado correctamente");
                System.out.println("## Verificando actualizacion: " + profesorRepository.findById(nuevoProfesor.getIdProfesor()));
            }else{
                System.err.println("¡¡ ERROR - no se pudo actualizar el profesor !!");
            }
            
            //Listar todos los profesores
            System.out.println("\n Test 17: Listar todos los profesores");
            List<Profesor> profesorTodos = profesorRepository.findAll();
            if (!profesorTodos.isEmpty()) {
                System.out.println("## Profesores encontrados: " + profesorTodos.size());
                profesorTodos.forEach(System.out::println);
            }else{
                System.err.println("¡¡ ERROR - no se pudieron listar los profesores !!");
            }

            //Buscando profesores por especialidad
            System.out.println("\n Buscando un profesor por su especialidad");
            List<Profesor> profesoresMatematica = profesorRepository.findByEspecialidad("Matematica");
            if (!profesoresMatematica.isEmpty()) {
                System.out.println("## Profesores de matematica encontrados: " + profesoresMatematica.size());
                profesoresMatematica.forEach(System.out::println);
            }else{
                System.err.println("¡¡ ERROR - no se encontraron profesores de matematica !!");
            }

            // Eliminar un profesor
            System.out.println("\n Test 18: Eliminando profesor " + nuevoProfesor.getIdProfesor());
            int filasAfectadasProfesorDelete = profesorRepository.delete(nuevoProfesor.getIdProfesor());  
            if (filasAfectadasProfesorDelete==1) {
                System.out.println("## Profesor " + nuevoProfesor.getIdProfesor() + "eliminado correctamente");
                System.out.println("Verificando eliminacion: " + profesorRepository.findById(nuevoProfesor.getIdProfesor()));
            }else{
                System.err.println("¡¡ ERROR - no se pudo eliminar el profesor");
            }

            //Pruebas para Materias


            // Creando una materia
            System.out.println("\n Test 19: Creando una materia");
            Materia nuevaMateria = new Materia(0,"Matematica segundo primaria", "Matematica inicial para segundo año de primaria", 1);
            materiaRepository.create(nuevaMateria);
            if (nuevaMateria.getIdMateria()>0) {
                System.out.println("## Materia creada con ID " + nuevaMateria.getIdMateria());
                System.out.println(nuevaMateria);

            }else{
                System.err.println("¡¡ ERROR - no se pudo crear la materia");
            }

            //Buscando una materia por ID
            System.out.println("\n Test 20: buscando una materia por ID " + nuevaMateria.getIdMateria());
            Materia materiaEncontrada = materiaRepository.findById(nuevaMateria.getIdMateria());
            if (materiaEncontrada!=null) {
                System.out.println("## Materia encontrada: " +  materiaEncontrada);
            }else{
                System.err.println("¡¡ ERROR - no se encontró la materia con ID " + nuevaMateria.getIdMateria());
            }

            //Buscando una materia por ID inexistente
            System.out.println("\n Test 21: buscando una materia con ID 9999 inexistente");
            Materia materiaNoEncontrada = materiaRepository.findById(9999);
            if (materiaNoEncontrada!=null) {
                System.out.println("## Materia encontrada: " + materiaNoEncontrada);
            }else{
                System.err.println("¡¡ ERROR - no se encontro la materia con id 9999");
            }

            //Buscando una materia por profesor
            System.out.println("\n>>> Test : buscando materia por profesor");
            List<Materia> materiasPorProfesor = materiaRepository.findByProfesor(3);
            if(!materiasPorProfesor.isEmpty()){
                System.out.println(" ## Materia por profesor encontrada: " + materiasPorProfesor.size());
                materiasPorProfesor.forEach(System.out::println);
            } else{
                System.err.println(" ¡¡ No se encontraron cursos para LUNES por la MAÑANA");
            }

            //Actualizar una materia
            System.out.println("\n Test 22: Actualizando una materia " + nuevaMateria.getIdMateria());
            nuevaMateria.setNombreMateria("Lengua y literatura");
            nuevaMateria.setDescripcion("Lengua y literatura para segundo primaria");
            int filasAfectadasMateria = materiaRepository.update(nuevaMateria);
            if (filasAfectadasMateria==1) {
                System.out.println("## Materia " + nuevaMateria.getIdMateria() + "Actualizada correctamente");
                System.out.println("Verificando actualizacion " + materiaRepository.findById(nuevaMateria.getIdMateria()));
            }else{
                System.err.println("¡¡ ERROR - no se pudo actualizar la materia");
            }

            // Listar todas las materias
            System.out.println("\n Test 23: Listando todas las materias");
            List<Materia> materiasTodas = materiaRepository.findAll();
            if (!materiasTodas.isEmpty()) {
                System.out.println("## Materias encontradas: " + materiasTodas.size());
                materiasTodas.forEach(System.out::println);
            }else{
                System.err.println("¡¡ ERROR - no se encontraron las materias");
            }

            //Eliminando una materia
            System.out.println("\n Test 24: Eliminando una materia " + nuevaMateria.getIdMateria());
            int filasAfectadasMateriaDelete = materiaRepository.delete(nuevaMateria.getIdMateria());
            if (filasAfectadasMateriaDelete==1) {
                System.out.println("## Materia " + nuevaMateria.getIdMateria() + " eliminado correctamente");
                System.out.println("Verificando eliminacion: " + materiaRepository.findById(nuevaMateria.getIdMateria()));
            }else{
                System.err.println("¡¡ ERROR - no se pudo eliminar la materia");
            }

            //Pruebas para calificaciones

            //Creando una nueva calificacion
            System.out.println("\n Test 25: Creando una calificacion");
            Calificacion nuevCalificacion = new Calificacion(0, 2, 2, 7.0, LocalDate.of(2025, 6, 20), TipoEvaluacion.PRUEBA);
            calificacionRepository.create(nuevCalificacion);
            if (nuevCalificacion.getIdCalificacion()>0) {
                System.out.println("Calificacion creada correctamente con el ID " + nuevCalificacion.getIdCalificacion());
                System.out.println(nuevCalificacion);
            }else{
                System.err.println("¡¡ ERROR - la calificacion no se pudo crear !!");
            }
            

            //Buscando una calificacion por ID
            System.out.println("\n Test 26: Buscando una calificacion por id " + nuevCalificacion.getIdCalificacion());
            Calificacion calificacionEncontrada = calificacionRepository.findById(nuevCalificacion.getIdCalificacion());
            if (calificacionEncontrada!=null) {
                System.out.println("## Calificacion encontrada " + nuevCalificacion);
            }else{
                System.err.println("¡¡ ERROR - no se encontro la calificacion con ID " + nuevCalificacion.getIdCalificacion());
            }

            //Listar todas las calificaciones
            System.out.println("\n Test 27: Listar todas las calificaciones");
            List<Calificacion> calificacionTodas = calificacionRepository.findAll();
            if (!calificacionTodas.isEmpty()) {
                System.out.println("## Calificaciones encontradas: " + calificacionTodas.size());
            }else{
                System.err.println("¡¡ ERROR - no se encontraron las calificaciones");
            }

            //Buscar las calificaciones por alumno
            System.out.println("\n>>> Test : buscando calificaciones por alumno");
            List<Calificacion> calificacionesPorAlumno = calificacionRepository.findByAlumno(15);
            if(!calificacionesPorAlumno.isEmpty()){
                System.out.println(" ## calificaciones por alumno encontradas " + calificacionesPorAlumno.size());
                calificacionesPorAlumno.forEach(System.out::println);
            } else{
                System.err.println(" ¡¡ ERROR - No se encontraron calificaciones para el alumno !!");
            }

            //Actualizar una calificacion
            System.out.println("\n Test: Actualizando una calificacion " + nuevCalificacion.getIdCalificacion());
            nuevCalificacion.setNota(9.0);
            int filasAfectadasCalificacion = calificacionRepository.update(nuevCalificacion);
            if(filasAfectadasCalificacion==1){
                System.out.println(" ## Calificacion " + nuevCalificacion.getIdCalificacion() + " actualizada correctamente.");
                System.out.println("Verificando actualización: " + calificacionRepository.findById(nuevCalificacion.getIdCalificacion()));
            } else {
                System.err.println(" ¡¡ ERROR - no se pudo actualizar la calificacion !!");
            }

            //Borrar una calificacion
            System.out.println("\n Borrando una calificacion " + nuevCalificacion.getIdCalificacion());
            int filasAfectadasCalificacionDelete = calificacionRepository.delete(nuevCalificacion.getIdCalificacion());
            if (filasAfectadasCalificacionDelete == 1) {
                System.out.println("## Calificacion " + nuevCalificacion.getIdCalificacion() + " eliminado correctamente");
                System.out.println("Verificando eliminacion: " + calificacionRepository.findById(nuevCalificacion.getIdCalificacion()));
            }else{
                System.err.println("¡¡ ERROR - no se pudo eliminar la calificacion");
            }


        } catch (Exception e) {
            System.out.println("¡¡ ERROR de la Base de Datos durante las pruebas !!");
            e.printStackTrace();
        } finally {
            System.out.println("\n<<< Finalizando pruebas >>>");
            System.out.println("\n<<< Contexto de Spring finalizado >>>");
        }
    }
}