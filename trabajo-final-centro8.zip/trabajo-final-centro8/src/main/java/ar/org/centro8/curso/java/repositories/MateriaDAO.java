package ar.org.centro8.curso.java.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.stereotype.Repository;

import ar.org.centro8.curso.java.entities.Materia;
import ar.org.centro8.curso.java.repositories.interfaces.I_MateriaRepository;

@Repository
public class MateriaDAO implements I_MateriaRepository {

    private final DataSource dataSource;

    private static final String SQL_CREATE = "INSERT INTO materias(nombre, descripcion) VALUES (?, ?)";

    private static final String SQL_FIND_BY_ID = "SELECT * FROM materias WHERE id=?";

    private static final String SQL_FIND_ALL = "SELECT * FROM materias";

    private static final String SQL_UPDATE = "UPDATE materias SET nombre=?, descripcion=? WHERE id=?";

    private static final String SQL_DELETE = "DELETE FROM materias WHERE id=?";

    private static final String SQL_FIND_BY_PROFESOR = "SELECT * FROM materias WHERE id_profesor=?";

    public MateriaDAO(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @Override
    public void create(Materia materia) throws SQLException {
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_CREATE, java.sql.Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, materia.getNombreMateria());
            ps.setString(2, materia.getDescripcion());

            ps.executeUpdate();

            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    materia.setIdMateria(keys.getInt(1));
                }
            }
        }
    }

    @Override
    public Materia findById(int id) throws SQLException {
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_ID)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
            }
        }
        return null;
    }

    @Override
    public List<Materia> findAll() throws SQLException {
        List<Materia> materias = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_FIND_ALL);
                ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                materias.add(mapRow(rs));
            }
        }
        return materias;
    }

    @Override
    public int update(Materia materia) throws SQLException {
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_UPDATE)) {
            ps.setString(1, materia.getNombreMateria());
            ps.setString(2, materia.getDescripcion());
            ps.setInt(3, materia.getIdMateria());
            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas;
        }
    }

    @Override
    public int delete(int id) throws SQLException {
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_DELETE)) {
            ps.setInt(1, id);
            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas;
        }
    }

    @Override
    public List<Materia> findByProfesor(int idProfesor) throws SQLException {
        List<Materia> materias = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_PROFESOR)) {
            ps.setInt(1, idProfesor);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    materias.add(mapRow(rs));
                }
            }
        }
        return materias;
    }

    public Materia mapRow(ResultSet rs) throws SQLException {
        Materia materia = new Materia();
        materia.setIdMateria(rs.getInt("id"));
        materia.setNombreMateria(rs.getString("nombre"));
        materia.setDescripcion(rs.getString("descripcion"));
        return materia;
    }

}
