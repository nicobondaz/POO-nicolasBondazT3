package ar.org.centro8.curso.java.enums;

public enum TipoEvaluacion {
    PRUEBA, TP, CARPETA, ORAL;
}
