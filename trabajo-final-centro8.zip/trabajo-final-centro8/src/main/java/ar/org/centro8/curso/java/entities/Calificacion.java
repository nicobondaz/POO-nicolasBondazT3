package ar.org.centro8.curso.java.entities;

import java.time.LocalDate;

import ar.org.centro8.curso.java.enums.TipoEvaluacion;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Calificacion {
    private Integer idCalificacion;
    private Integer idAlumno;
    private Integer idMateria;
    private Double nota;
    private LocalDate fecha;
    private TipoEvaluacion tipoEvaluacion;
}
