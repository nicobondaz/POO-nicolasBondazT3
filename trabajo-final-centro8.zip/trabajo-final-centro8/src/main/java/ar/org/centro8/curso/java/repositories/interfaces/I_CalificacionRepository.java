package ar.org.centro8.curso.java.repositories.interfaces;

import java.sql.SQLException;
import java.util.List;

import ar.org.centro8.curso.java.entities.Calificacion;

public interface I_CalificacionRepository {
    void create(Calificacion calificacion) throws SQLException;
    Calificacion findById(int id) throws SQLException;
    List<Calificacion> findAll() throws SQLException;
    int update(Calificacion calificacion) throws SQLException;
    int delete(int id) throws SQLException;
    List<Calificacion> findByAlumno(int idAlumno) throws SQLException;
}
