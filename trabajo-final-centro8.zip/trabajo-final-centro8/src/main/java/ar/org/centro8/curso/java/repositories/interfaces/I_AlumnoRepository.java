package ar.org.centro8.curso.java.repositories.interfaces;

import java.sql.SQLException;
import java.util.List;

import ar.org.centro8.curso.java.entities.Alumno;

public interface I_AlumnoRepository {
    void create(Alumno alumno) throws SQLException;
    Alumno findById(int id) throws SQLException;
    List<Alumno> findAll() throws SQLException;
    int update(Alumno alumno) throws SQLException;
    int delete(int id) throws SQLException;
    List<Alumno> findByCurso(int idCurso) throws SQLException;
}
