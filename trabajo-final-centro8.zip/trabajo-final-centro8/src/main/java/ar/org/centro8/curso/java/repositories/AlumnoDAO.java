package ar.org.centro8.curso.java.repositories;

import java.sql.SQLException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.stereotype.Repository;

import ar.org.centro8.curso.java.entities.Alumno;
import ar.org.centro8.curso.java.repositories.interfaces.I_AlumnoRepository;

@Repository
public class AlumnoDAO implements I_AlumnoRepository {

    private final DataSource DATASOURCE;

    private static final String SQL_CREATE = "INSERT INTO alumnos(nombre, apellido, dni, fechaNacimiento, email, padres, idCurso) VALUES (?,?,?,?,?,?,?)";

    private static final String SQL_FIND_BY_ID = "SELECT * FROM alumnos WHERE id=?";

    private static final String SQL_FIND_ALL = "SELECT * FROM alumnos";

    private static final String SQL_UPDATE = "UPDATE alumnos SET nombre=?, apellido=?, dni=?, fechaNacimiento=?, email=?, padres=?, idCurso=? WHERE id=?";

    private static final String SQL_DELETE = "DELETE FROM alumnos WHERE id=?";

    private static final String SQL_FIND_BY_CURSO = "SELECT * FROM alumnos WHERE idCurso=?";

    public AlumnoDAO(DataSource dataSource) {
        this.DATASOURCE = dataSource;
    }

    @Override
    public void create(Alumno alumno) throws SQLException {
       try (Connection conn = DATASOURCE.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_CREATE)) {
            ps.setString(1, alumno.getNombre());
            ps.setString(2, alumno.getApellido());
            ps.setString(3, alumno.getDni());
            ps.setDate(4, java.sql.Date.valueOf(alumno.getFechaNacimiento()));
            ps.setString(5, alumno.getEmail());
            ps.setString(6, alumno.getPadres());
            ps.setInt(7, alumno.getIdCurso());

            ps.executeUpdate();

            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    alumno.setIdAlumno(keys.getInt(1));
                }
            }
        }
    }

    @Override
    public Alumno findById(int id) throws SQLException {
       try(Connection conn = DATASOURCE.getConnection();
            PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_ID)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
            }
        }
        return null;
    }

    @Override
    public List<Alumno> findAll() throws SQLException {
        List<Alumno> alumnos = new ArrayList<>();
        try (Connection conn = DATASOURCE.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_ALL);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                alumnos.add(mapRow(rs));
            }
            return alumnos;
        }
    }

    @Override
    public int update(Alumno alumno) throws SQLException {
       try (Connection conn = DATASOURCE.getConnection();
            PreparedStatement ps = conn.prepareStatement(SQL_UPDATE)) {
            ps.setString(1, alumno.getNombre());
            ps.setString(2, alumno.getApellido());
            ps.setString(3, alumno.getDni());
            ps.setDate(4, java.sql.Date.valueOf(alumno.getFechaNacimiento()));
            ps.setString(5, alumno.getEmail());
            ps.setString(6, alumno.getPadres());
            ps.setInt(7, alumno.getIdCurso());
            ps.setInt(8, alumno.getIdAlumno());
            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas;
        }
    }

    @Override
    public int delete(int id) throws SQLException {
        try (Connection conn = DATASOURCE.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_DELETE)) {
            ps.setInt(1, id);
            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas;
        }
    }

    @Override
    public List<Alumno> findByCurso(int idCurso) throws SQLException {
       List<Alumno> alumnos = new ArrayList<>();
        try (Connection conn = DATASOURCE.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_CURSO)) {
            ps.setInt(1, idCurso);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    alumnos.add(mapRow(rs));
                }
            }
        }
        return alumnos;
    }

    private Alumno mapRow(ResultSet rs) throws SQLException {
        Alumno alumno = new Alumno();
        alumno.setIdAlumno(rs.getInt("id"));
        alumno.setNombre(rs.getString("nombre"));
        alumno.setApellido(rs.getString("apellido"));
        alumno.setDni(rs.getString("dni"));
        alumno.setFechaNacimiento(rs.getDate("fechaNacimiento").toLocalDate());
        alumno.setEmail(rs.getString("email"));
        alumno.setPadres(rs.getString("padres"));
        alumno.setIdCurso(rs.getInt("idCurso"));
        return alumno;
    }

}
