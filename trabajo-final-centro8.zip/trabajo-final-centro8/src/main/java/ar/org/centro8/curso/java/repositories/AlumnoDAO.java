package ar.org.centro8.curso.java.repositories;

import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.stereotype.Repository;

import ar.org.centro8.curso.java.entities.Alumno;
import ar.org.centro8.curso.java.repositories.interfaces.I_AlumnoRepository;

@Repository
public class AlumnoDAO implements I_AlumnoRepository {

    private final DataSource DATASOURCE;

    private static final String SQL_CREATE = "INSERT INTO alumnos(nombre, apellido, dni, fechaNacimiento, email, padres, idCurso) VALUES (?,?,?,?,?,?,?)";

    private static final String SQL_FIND_BY_ID = "SELECT * FROM alumnos WHERE id=?";

    @Override
    public void create(Alumno alumno) throws SQLException {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'create'");
    }

    @Override
    public Alumno findById(int id) throws SQLException {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'findById'");
    }

    @Override
    public List<Alumno> findAll() throws SQLException {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'findAll'");
    }

    @Override
    public int update(Alumno alumno) throws SQLException {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'update'");
    }

    @Override
    public int delete(int id) throws SQLException {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'delete'");
    }

    @Override
    public List<Alumno> findByCurso(int idCurso) throws SQLException {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'findByCurso'");
    }

}
