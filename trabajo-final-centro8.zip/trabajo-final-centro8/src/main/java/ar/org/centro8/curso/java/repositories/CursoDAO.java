package ar.org.centro8.curso.java.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.stereotype.Repository;

import ar.org.centro8.curso.java.entities.Curso;
import ar.org.centro8.curso.java.enums.Division;
import ar.org.centro8.curso.java.enums.Nivel;
import ar.org.centro8.curso.java.enums.Turno;
import ar.org.centro8.curso.java.repositories.interfaces.I_CursoRepository;

@Repository
public class CursoDAO implements I_CursoRepository {

    private final DataSource dataSource;

    private static final String SQL_CREATE = "INSERT INTO cursos(nombre, descripcion, fecha_inicio, fecha_fin) VALUES (?,?,?,?)";

    private static final String SQL_FIND_BY_ID = "SELECT * FROM cursos WHERE id=?";

    private static final String SQL_FIND_ALL = "SELECT * FROM cursos";

    private static final String SQL_UPDATE = "UPDATE cursos SET nombre=?, descripcion=?, fecha_inicio=?, fecha_fin=? WHERE id=?";

    private static final String SQL_DELETE = "DELETE FROM cursos WHERE id=?";

    private static final String SQL_FIND_BY_ANIO_AND_TURNO = "SELECT * FROM cursos WHERE anio=? AND turno=?";

    public CursoDAO(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @Override
    public void create(Curso curso) throws SQLException {
        try (Connection conn = dataSource.getConnection()) {
            PreparedStatement ps = conn.prepareStatement(SQL_CREATE);
            ps.setString(1, curso.getDivision().name());
            ps.setInt(2, curso.getAnio());
            ps.setString(3, curso.getNivel().name());
            ps.setString(4, curso.getTurno().name());
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    curso.setIdCurso(keys.getInt(1));
                }
            }
        }
    }

    @Override
    public Curso findById(int id) throws SQLException {
        try (Connection conn = dataSource.getConnection()) {
            PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_ID);
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
            }
        }
        return null;
    }

    @Override
    public List<Curso> findAll() throws SQLException {
        List<Curso> cursos = new ArrayList<>();
        try (Connection conn = dataSource.getConnection()) {
            PreparedStatement ps = conn.prepareStatement(SQL_FIND_ALL);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    cursos.add(mapRow(rs));
                }
            }
        }
        return cursos;
    }

    @Override
    public int update(Curso curso) throws SQLException {
        try (Connection conn = dataSource.getConnection()) {
            PreparedStatement ps = conn.prepareStatement(SQL_UPDATE);
            ps.setString(1, curso.getDivision().name());
            ps.setInt(2, curso.getAnio());
            ps.setString(3, curso.getNivel().name());
            ps.setString(4, curso.getTurno().name());
            ps.setInt(5, curso.getIdCurso());
            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas;
        }
    }

    @Override
    public int delete(int id) throws SQLException {
        try (Connection conn = dataSource.getConnection()) {
            PreparedStatement ps = conn.prepareStatement(SQL_DELETE);
            ps.setInt(1, id);
            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas;
        }

    }

    @Override
    public List<Curso> findByAnioAndTurno(int anio, Turno turno) throws SQLException {
        List<Curso> cursos = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_ANIO_AND_TURNO)){
            ps.setInt(1, anio);
            ps.setString(2, turno.name());
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    cursos.add(mapRow(rs));
                }
            }
        }
        return cursos;
        
    }

    public Curso mapRow(ResultSet rs) throws SQLException {
        Curso curso = new Curso();
        curso.setIdCurso(rs.getInt("id"));
        curso.setDivision(Division.valueOf(rs.getString("division")));
        curso.setAnio(rs.getInt("anio"));
        curso.setNivel(Nivel.valueOf(rs.getString("nivel")));
        curso.setTurno(Turno.valueOf(rs.getString("turno")));
        return curso;
    }
}
