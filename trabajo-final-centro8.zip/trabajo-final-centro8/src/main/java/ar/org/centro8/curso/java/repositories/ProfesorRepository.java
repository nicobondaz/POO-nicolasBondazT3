package ar.org.centro8.curso.java.repositories;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.stereotype.Repository;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.Date;

import ar.org.centro8.curso.java.entities.Profesor;
import ar.org.centro8.curso.java.repositories.interfaces.I_ProfesorRepository;

@Repository
public class ProfesorRepository implements I_ProfesorRepository {
    private final DataSource DATASOURCE;

    private static final String SQL_CREATE = "INSERT INTO profesores(nombre, apellido, dni, fecha_nacimiento, email, numero_telefonico, especialidad) VALUES (?,?,?,?,?,?,?)";

    private static final String SQL_FIND_BY_ID = "SELECT * FROM profesores WHERE id_profesor=?";

    private static final String SQL_FIND_ALL = "SELECT * FROM profesores";

    private static final String SQL_UPDATE = "UPDATE profesores SET nombre=?, apellido=?, dni=?, fecha_nacimiento=?, email=?, numero_telefonico=?, especialidad=? WHERE id_profesor=?";

    private static final String SQL_DELETE = "DELETE FROM profesores WHERE id_profesor=?";

    private static final String SQL_FIND_BY_ESPECIALIDAD = "SELECT * FROM profesores WHERE especialidad=?";

    public ProfesorRepository(DataSource dataSource) {
        this.DATASOURCE = dataSource;
    }

    @Override
    public void create(Profesor profesor) throws SQLException {
        try (Connection conn = DATASOURCE.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_CREATE, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, profesor.getNombre());
            ps.setString(2, profesor.getApellido());
            ps.setString(3, profesor.getDni());
            ps.setDate(4, Date.valueOf(profesor.getFechaNacimiento()));
            ps.setString(5, profesor.getEmail());
            ps.setString(6, profesor.getNumeroTelefonico());
            ps.setString(7, profesor.getEspecialidad());

            ps.executeUpdate();

            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    profesor.setIdProfesor(keys.getInt(1));
                }
            }
        }
    }

    @Override
    public Profesor findById(int id) throws SQLException {
        try (Connection conn = DATASOURCE.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_ID)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
            }
        }
        return null;
    }

    @Override
    public List<Profesor> findAll() throws SQLException {
        List<Profesor> profesores = new ArrayList<>();
        try (Connection conn = DATASOURCE.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_FIND_ALL);
                ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                profesores.add(mapRow(rs));
            }
        }
        return profesores;
    }

    @Override
    public int update(Profesor profesor) throws SQLException {
        try (Connection conn = DATASOURCE.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_UPDATE)) {
            ps.setString(1, profesor.getNombre());
            ps.setString(2, profesor.getApellido());
            ps.setString(3, profesor.getDni());
            ps.setDate(4, Date.valueOf(profesor.getFechaNacimiento()));
            ps.setString(5, profesor.getEmail());
            ps.setString(6, profesor.getNumeroTelefonico());
            ps.setString(7, profesor.getEspecialidad());
            ps.setInt(8, profesor.getIdProfesor());
            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas;
        }
    }

    @Override
    public int delete(int id) throws SQLException {
        try (Connection conn = DATASOURCE.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_DELETE)) {
            ps.setInt(1, id);
            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas;
        }
    }

    @Override
    public List<Profesor> findByEspecialidad(String especialidad) throws SQLException {
        List<Profesor> profesores = new ArrayList<>();
        try (Connection conn = DATASOURCE.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_ESPECIALIDAD)) {
            ps.setString(1, especialidad);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    profesores.add(mapRow(rs));
                }
            }
        }
        return profesores;
    }

    public Profesor mapRow(ResultSet rs) throws SQLException {
        Profesor profesor = new Profesor();
        profesor.setIdProfesor(rs.getInt("id_profesor"));
        profesor.setNombre(rs.getString("nombre"));
        profesor.setApellido(rs.getString("apellido"));
        profesor.setDni(rs.getString("dni"));
        profesor.setFechaNacimiento(rs.getDate("fecha_nacimiento").toLocalDate());
        profesor.setEmail(rs.getString("email"));
        profesor.setNumeroTelefonico(rs.getString("numero_telefonico"));
        profesor.setEspecialidad(rs.getString("especialidad"));
        return profesor;
    }

}
