package ar.org.centro8.curso.java.repositories;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.stereotype.Repository;

import ar.org.centro8.curso.java.enums.TipoEvaluacion;

import ar.org.centro8.curso.java.entities.Calificacion;
import ar.org.centro8.curso.java.repositories.interfaces.I_CalificacionRepository;

@Repository
public class CalificacionRepository implements I_CalificacionRepository {

    private final DataSource dataSource;

    private static final String SQL_CREATE = "INSERT INTO calificaciones(id_alumno, id_materia, nota, fecha, tipo_evaluacion) VALUES (?,?,?,?,?)";

    private static final String SQL_FIND_BY_ID = "SELECT * FROM calificaciones WHERE id_calificacion=?";

    private static final String SQL_FIND_ALL = "SELECT * FROM calificaciones";

    private static final String SQL_UPDATE = "UPDATE calificaciones SET id_alumno=?, id_materia=?, nota=?, fecha=?, tipo_evaluacion=? WHERE id_calificacion=?";

    private static final String SQL_DELETE = "DELETE FROM calificaciones WHERE id_calificacion=?";

    private static final String SQL_FIND_BY_ALUMNO = "SELECT * FROM calificaciones WHERE id_alumno=?";

    public CalificacionRepository(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @Override
    public void create(Calificacion calificacion) throws SQLException {
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_CREATE, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, calificacion.getIdAlumno());
            ps.setInt(2, calificacion.getIdMateria());
            ps.setDouble(3, calificacion.getNota());
            ps.setDate(4, Date.valueOf(calificacion.getFecha()));
            ps.setString(5, calificacion.getTipoEvaluacion().name());

            ps.executeUpdate();

            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    calificacion.setIdCalificacion(keys.getInt(1));
                }
            }
        }
    }

    @Override
    public Calificacion findById(int id) throws SQLException {
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_ID)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
            }
        }
        return null;
    }

    @Override
    public List<Calificacion> findAll() throws SQLException {
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_FIND_ALL);
                ResultSet rs = ps.executeQuery()) {
            List<Calificacion> calificaciones = new ArrayList<>();
            while (rs.next()) {
                calificaciones.add(mapRow(rs));
            }
            return calificaciones;
        }
    }

    @Override
    public int update(Calificacion calificacion) throws SQLException {
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_UPDATE)) {
            ps.setInt(1, calificacion.getIdAlumno());
            ps.setInt(2, calificacion.getIdMateria());
            ps.setDouble(3, calificacion.getNota());
            ps.setDate(4, Date.valueOf(calificacion.getFecha()));
            ps.setString(5, calificacion.getTipoEvaluacion().name());
            ps.setInt(6, calificacion.getIdCalificacion());
            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas;
        }
    }

    @Override
    public int delete(int id) throws SQLException {
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_DELETE)) {
            ps.setInt(1, id);
            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas;
        }
    }

    @Override
    public List<Calificacion> findByAlumno(int idAlumno) throws SQLException {
        List<Calificacion> calificaciones = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_ALUMNO)) {
            ps.setInt(1, idAlumno);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    calificaciones.add(mapRow(rs));
                }
            }
        }
        return calificaciones;
    }

    private Calificacion mapRow(ResultSet rs) throws SQLException {
        Calificacion calificacion = new Calificacion();
        calificacion.setIdCalificacion(rs.getInt("id_calificacion"));
        calificacion.setIdAlumno(rs.getInt("id_alumno"));
        calificacion.setIdMateria(rs.getInt("id_materia"));
        calificacion.setNota(rs.getDouble("nota"));
        calificacion.setFecha(rs.getDate("fecha").toLocalDate());
        calificacion.setTipoEvaluacion(TipoEvaluacion.valueOf(rs.getString("tipo_evaluacion")));
        return calificacion;
    }

}
