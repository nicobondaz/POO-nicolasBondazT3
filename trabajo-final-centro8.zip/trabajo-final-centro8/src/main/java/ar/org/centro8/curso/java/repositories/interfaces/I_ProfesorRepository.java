package ar.org.centro8.curso.java.repositories.interfaces;

import java.sql.SQLException;
import java.util.List;

import ar.org.centro8.curso.java.entities.Profesor;

public interface I_ProfesorRepository {
    void create(Profesor profesor) throws SQLException;
    Profesor findById(int id) throws SQLException;
    List<Profesor> findAll() throws SQLException;
    int update(Profesor profesor) throws SQLException;
    int delete(int id) throws SQLException;
    List<Profesor> findByEspecialidad(String especialidad) throws SQLException;
}
