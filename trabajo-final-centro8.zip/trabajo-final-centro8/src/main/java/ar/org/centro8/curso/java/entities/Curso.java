package ar.org.centro8.curso.java.entities;

import ar.org.centro8.curso.java.enums.Nivel;
import ar.org.centro8.curso.java.enums.Turno;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Curso {
    private Integer idCurso;
    private int anio;
    private Nivel nivel;
    private Turno turno;
    private String division;
}
