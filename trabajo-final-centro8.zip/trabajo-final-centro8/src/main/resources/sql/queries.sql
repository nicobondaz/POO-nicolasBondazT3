-- esta query nos da informacion de los alumnos filtrando por dni
select a.nombre, a.apellido, a.dni, a.email, a.padres, a.fecha_nacimiento, m.nombre_materia
from calificaciones c
join alumnos a on c.id_alumno = a.id_alumno
join materias m on c.id_materia = m.id_materia
where a.dni = '87654321';

-- esta query devuelve el promedio de las notas de cada alumno segun la materia
select a.nombre, a.apellido, m.nombre_materia, round(avg(c.nota),1) as nota_final
from calificaciones c
join alumnos a on c.id_alumno = a.id_alumno
join materias m on c.id_materia = m.id_materia
group by a.id_alumno, m.id_materia;


-- esta query devuelve los alumnos con su curso
SELECT a.nombre, a.apellido, c.anio, c.nivel, c.division
FROM alumnos a
JOIN cursos c ON a.id_curso = c.id_curso;


-- esta query busca el promedio de cada alumno y filtra par mostrar a los desaprobados
select a.nombre, a.apellido, m.nombre_materia, round(avg(c.nota),1) as nota_final
from calificaciones c 
join alumnos a on c.id_alumno = a.id_alumno
join materias m on c.id_materia = m.id_materia
where c.nota < 6
group by a.id_alumno, m.id_materia;