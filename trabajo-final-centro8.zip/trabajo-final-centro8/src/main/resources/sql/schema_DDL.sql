drop database if exists colegio;

create database colegio;

use colegio;

create table profesores(
	id_profesor int auto_increment primary key,
    nombre varchar(50) not null,
    apellido varchar(50) not null,
    dni varchar(8) not null unique,
    fecha_nacimiento date not null,
    email varchar(100) not null,
    numero_telefonico varchar(20) not null,
    especialidad varchar(50) not null
    );

create table cursos(
	id_curso int auto_increment primary key,
    anio int not null check (anio between 1 and 6),
    nivel enum("Primaria", "Secundaria") not null,
    turno enum("mañana", "tarde") not null,
    division enum("economia", "comunicaciones", "naturales")
);

create table alumnos(
	id_alumno int auto_increment primary key,
	nombre varchar(50) not null,
    apellido varchar(50) not null,
    dni varchar(8) not null unique,
    fecha_nacimiento date not null,
    email varchar(100) not null,
    padres varchar(100) not null,
    id_curso int not null
);

create table materias(
	id_materia int auto_increment primary key,
    nombre_materia varchar(50) not null,
    descripcion varchar(200),
    id_profesor int not null
);

create table calificaciones(
	id_calificacion int auto_increment primary key,
    id_alumno int not null,
    id_materia int not null,
    nota decimal(3,1) check (nota between 1 and 10) not null,
    fecha date not null,
    tipo_evaluacion enum("Prueba",  "TP", "Carpeta", "Oral") not null
);

alter table alumnos
add constraint fk_alumno_curso
foreign key (id_curso) references cursos(id_curso);

alter table materias
add constraint fk_materia_profesor
foreign key (id_profesor) references profesores(id_profesor);

alter table calificaciones 
add constraint fk_calificacion_alumno
foreign key (id_alumno) references alumnos(id_alumno);

alter table calificaciones 
add constraint fk_calificacion_materia
foreign key (id_materia) references materias(id_materia);